package com.green.CarManage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarManageApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarManageApplication.class, args);
	}

}
