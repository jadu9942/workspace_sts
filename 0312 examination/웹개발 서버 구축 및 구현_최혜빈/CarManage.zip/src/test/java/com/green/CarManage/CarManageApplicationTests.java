package com.green.CarManage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarManageApplicationTests {

	@Test
	void contextLoads() {
	}

}
